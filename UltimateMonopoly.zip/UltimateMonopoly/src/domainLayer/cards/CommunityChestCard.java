package domainLayer.cards;

public abstract class CommunityChestCard extends Card{

	public CommunityChestCard(String name, Boolean keepable) {
		super(name, keepable);
		// TODO Auto-generated constructor stub
	}


}
