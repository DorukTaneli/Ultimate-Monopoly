package domainLayer.cards;

public abstract class ChanceCard extends Card{
	
	public ChanceCard(String name, Boolean keepable) {
		super(name, keepable);
		// TODO Auto-generated constructor stub
	}
	
	
	
}
