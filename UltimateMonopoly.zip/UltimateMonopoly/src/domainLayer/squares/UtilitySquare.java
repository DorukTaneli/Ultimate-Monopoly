package domainLayer.squares;

import domainLayer.Player;

public class UtilitySquare extends PropertySquare{

	
	public UtilitySquare(String name, int index, int price, int rent) {
		super(name, index, price, rent);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void landedOn(Player p) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void passedOn(Player p) {
		// TODO Auto-generated method stub
		
	}
}
